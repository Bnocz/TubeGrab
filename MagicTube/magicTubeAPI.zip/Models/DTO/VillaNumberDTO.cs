﻿namespace MagicTube.Models.DTO { 
using System.ComponentModel.DataAnnotations;

    public class VillaNumberDTO
    {
        public int VillaNo {  get; set; }

        public string SpecialDetails { get; set; }
    }
}
